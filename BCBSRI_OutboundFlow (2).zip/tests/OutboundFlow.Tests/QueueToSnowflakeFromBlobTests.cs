using System.Text.Json;
using System.Threading.Tasks;
using Moq;
using Xunit;
using OutboundFlow.Shared.Interfaces;
using OutboundFlowFunc.Functions;
using Microsoft.Extensions.Logging;
using OutboundFlow.Shared.Models;
using System.Collections.Generic;

public class QueueToSnowflakeFromBlobTests
{
    [Fact]
    public async Task Processes_PrimePended_Claims_Only()
    {
        var storageMock = new Mock<IStorageService>();
        var memberMock = new Mock<IMemberService>();
        var snowMock = new Mock<ISnowflakeService>();
        var logger = Mock.Of<ILogger<QueueToSnowflakeFromBlob>>();

        var claims = new List<ClaimEntity> {
            new ClaimEntity { ClaimId = "CLM-30001", MemberId = "MBR-201", Status = "PENDED", PrimePended = true },
            new ClaimEntity { ClaimId = "CLM-30002", MemberId = "MBR-202", Status = "APPROVED", PrimePended = false }
        };
        var blobContent = JsonSerializer.Serialize(claims);

        storageMock.Setup(s => s.DownloadStringAsync("claims-outbound2", "sample-blob.json")).ReturnsAsync(blobContent);
        memberMock.Setup(m => m.GetMemberAsync(It.IsAny<string>())).ReturnsAsync("{ "memberId": "MBR-201", "name": "Test" }");

        var func = new QueueToSnowflakeFromBlob(storageMock.Object, memberMock.Object, snowMock.Object, logger);

        var queueMsg = JsonSerializer.Serialize(new { data = new { url = "https://account.blob.core.windows.net/claims-outbound2/sample-blob.json" } });

        await func.RunAsync(queueMsg);

        snowMock.Verify(s => s.InsertClaimAsync(It.Is<ClaimEntity>(c => c.ClaimId == "CLM-30001"), It.IsAny<string>()), Times.Once);
        snowMock.Verify(s => s.InsertClaimAsync(It.Is<ClaimEntity>(c => c.ClaimId == "CLM-30002"), It.IsAny<string>()), Times.Never);
    }
}
