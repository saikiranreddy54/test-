using System.Threading.Tasks;
using Azure.Storage.Queues;
using OutboundFlow.Shared.Interfaces;

namespace OutboundFlowFunc.Services
{
    public class AzureQueueService : IQueueService
    {
        private readonly QueueServiceClient _client;
        public AzureQueueService(QueueServiceClient client) => _client = client;
        public async Task EnqueueAsync(string queueName, string message)
        {
            var q = _client.GetQueueClient(queueName);
            await q.CreateIfNotExistsAsync();
            await q.SendMessageAsync(System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(message)));
        }
    }
}
