using System;
using System.Threading.Tasks;
using OutboundFlow.Shared.Interfaces;
using OutboundFlow.Shared.Models;
using Snowflake.Data.Client;

namespace OutboundFlowFunc.Services
{
    public class SnowflakeService : ISnowflakeService
    {
        private readonly string _conn;
        private readonly string _db;
        private readonly string _schema;
        private readonly string _claimsTable;
        private readonly string _errorTable;

        public SnowflakeService(Microsoft.Extensions.Configuration.IConfiguration config)
        {
            _conn = config["Snowflake__ConnectionString"] ?? config["Snowflake:ConnectionString"];
            _db = config["Snowflake__Database"] ?? config["Snowflake:Database"];
            _schema = config["Snowflake__Schema"] ?? config["Snowflake:Schema"];
            _claimsTable = config["Snowflake__ClaimsTable"] ?? "CLAIMS";
            _errorTable = config["Snowflake__ErrorTable"] ?? "CLAIMS_ERROR";
        }

        public async Task InsertClaimAsync(ClaimEntity claim, string processingId)
        {
            if (string.IsNullOrWhiteSpace(_conn)) throw new ArgumentNullException("Snowflake connection string not configured");

            using var conn = new SnowflakeDbConnection();
            conn.ConnectionString = _conn;
            await conn.OpenAsync();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
INSERT INTO {_db}.{_schema}.{_claimsTable} (CLAIMID, MEMBERID, STATUS, AMOUNT, RECEIVEDDATE, PROCESSING_ID)
VALUES (:id, :member, :status, :amount, :received, :proc)";
            cmd.Parameters.Add(new SnowflakeDbParameter(":id", claim.ClaimId));
            cmd.Parameters.Add(new SnowflakeDbParameter(":member", claim.MemberId));
            cmd.Parameters.Add(new SnowflakeDbParameter(":status", claim.Status));
            cmd.Parameters.Add(new SnowflakeDbParameter(":amount", claim.ClaimAmount));
            cmd.Parameters.Add(new SnowflakeDbParameter(":received", claim.ServiceDate));
            cmd.Parameters.Add(new SnowflakeDbParameter(":proc", processingId));
            await cmd.ExecuteNonQueryAsync();
        }

        public async Task InsertErrorAsync(string claimId, string processingId, string errorMessage, string rawPayload)
        {
            if (string.IsNullOrWhiteSpace(_conn)) throw new ArgumentNullException("Snowflake connection string not configured");

            using var conn = new SnowflakeDbConnection();
            conn.ConnectionString = _conn;
            await conn.OpenAsync();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
INSERT INTO {_db}.{_schema}.{_errorTable} (CLAIMID, PROCESSING_ID, ERROR_MESSAGE, RAW_PAYLOAD, CREATED_AT)
VALUES (:id, :proc, :err, :raw, current_timestamp())";
            cmd.Parameters.Add(new SnowflakeDbParameter(":id", claimId));
            cmd.Parameters.Add(new SnowflakeDbParameter(":proc", processingId));
            cmd.Parameters.Add(new SnowflakeDbParameter(":err", errorMessage));
            cmd.Parameters.Add(new SnowflakeDbParameter(":raw", rawPayload));
            await cmd.ExecuteNonQueryAsync();
        }
    }
}
