using System.IO;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using OutboundFlow.Shared.Interfaces;
using System.Text;

namespace OutboundFlowFunc.Services
{
    public class AzureStorageService : IStorageService
    {
        private readonly BlobServiceClient _client;
        public AzureStorageService(BlobServiceClient client) => _client = client;

        public async Task UploadAsync(string containerName, string blobName, Stream content)
        {
            var container = _client.GetBlobContainerClient(containerName);
            await container.CreateIfNotExistsAsync();
            content.Position = 0;
            await container.GetBlobClient(blobName).UploadAsync(content, overwrite: true);
        }

        public async Task<string> DownloadStringAsync(string containerName, string blobName)
        {
            var container = _client.GetBlobContainerClient(containerName);
            var blob = container.GetBlobClient(blobName);
            if (!await blob.ExistsAsync()) return null;
            var resp = await blob.DownloadContentAsync();
            return resp.Value.Content.ToString();
        }

        public async Task UploadErrorBlobAsync(string containerName, string blobName, string content)
        {
            var errorContainer = _client.GetBlobContainerClient(containerName + "-errors");
            await errorContainer.CreateIfNotExistsAsync();
            var bytes = Encoding.UTF8.GetBytes(content);
            using var ms = new MemoryStream(bytes);
            await errorContainer.GetBlobClient(blobName).UploadAsync(ms, overwrite: true);
        }
    }
}
