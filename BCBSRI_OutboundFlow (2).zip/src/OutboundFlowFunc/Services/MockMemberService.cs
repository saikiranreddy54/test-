using System.Threading.Tasks;
using OutboundFlow.Shared.Interfaces;

namespace OutboundFlowFunc.Services
{
    public class MockMemberService : IMemberService
    {
        public Task<string> GetMemberAsync(string memberId)
        {
            // return mock member JSON
            return Task.FromResult($"{\"memberId\":\"{memberId}\",\"name\":\"John Doe\"}"); 
        }
    }
}
