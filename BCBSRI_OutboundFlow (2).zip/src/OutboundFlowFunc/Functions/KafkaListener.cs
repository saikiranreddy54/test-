using System;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using OutboundFlow.Shared.Interfaces;
using OutboundFlow.Shared.Models;
using System.IO;

namespace OutboundFlowFunc.Functions
{
    public class KafkaListener
    {
        private readonly IStorageService _storageService;
        private readonly IQueueService _queueService;
        private readonly ILogger<KafkaListener> _logger;

        public KafkaListener(IStorageService storageService, IQueueService queueService, ILogger<KafkaListener> logger)
        {
            _storageService = storageService;
            _queueService = queueService;
            _logger = logger;
        }

        // TimerTrigger used for local testing; replace with Kafka trigger in production
        [Function("KafkaListener")]
        public async Task Run([TimerTrigger("*/10 * * * * *")] TimerInfo timer)
        {
            _logger.LogInformation("KafkaListener timer invoked (local).");
        }

        public async Task ProcessMessageAsync(string kafkaMessage)
        {
            if (string.IsNullOrWhiteSpace(kafkaMessage)) return;

            var claim = JsonSerializer.Deserialize<ClaimEntity>(kafkaMessage);
            if (claim == null) return;

            if (!string.Equals(claim.Status, "IN_PROGRESS", StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogInformation($"Skipping claim {claim.ClaimId} status {claim.Status}");
                return;
            }

            var blobName = $"claim-{claim.ClaimId}-{DateTime.UtcNow:yyyyMMddHHmmssfff}.json";
            var ms = new MemoryStream(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(claim)));
            await _storageService.UploadAsync(Environment.GetEnvironmentVariable("Blob__RawContainer") ?? "raw-claims", blobName, ms);
            _logger.LogInformation($"Uploaded claim {claim.ClaimId} to blob {blobName}");

            await _queueService.EnqueueAsync(Environment.GetEnvironmentVariable("Queue__Name") ?? "inprogress-claims", JsonSerializer.Serialize(claim));
            _logger.LogInformation($"Enqueued claim {claim.ClaimId} to queue.");
        }
    }
}
