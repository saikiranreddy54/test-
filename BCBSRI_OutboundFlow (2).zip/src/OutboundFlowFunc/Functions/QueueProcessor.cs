using System;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using OutboundFlow.Shared.Interfaces;
using OutboundFlow.Shared.Models;
using System.IO;

namespace OutboundFlowFunc.Functions
{
    public class QueueProcessor
    {
        private readonly IStorageService _storageService;
        private readonly IMemberService _memberService;
        private readonly ISnowflakeService _snowflakeService;
        private readonly ILogger<QueueProcessor> _logger;

        public QueueProcessor(IStorageService storageService, IMemberService memberService, ISnowflakeService snowflakeService, ILogger<QueueProcessor> logger)
        {
            _storageService = storageService;
            _memberService = memberService;
            _snowflakeService = snowflakeService;
            _logger = logger;
        }

        [Function("QueueProcessor") ]
        public async Task RunAsync([QueueTrigger("inprogress-claims", Connection = "AzureWebJobsStorage")] string queueMessage)
        {
            if (string.IsNullOrWhiteSpace(queueMessage)) return;

            var claim = JsonSerializer.Deserialize<ClaimEntity>(queueMessage);
            if (claim == null) return;

            // Enrich
            var memberJson = await _memberService.GetMemberAsync(claim.MemberId ?? string.Empty);

            // Write enriched to processed blob
            var blobName = $"enriched-{claim.ClaimId}-{DateTime.UtcNow:yyyyMMddHHmmssfff}.json";
            var ms = new MemoryStream(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new { claim = claim, member = memberJson })));
            await _storageService.UploadAsync(Environment.GetEnvironmentVariable("Blob__ProcessedContainer") ?? "processed-claims", blobName, ms);

            // Insert into Snowflake (processingId uses claim id timestamp)
            var processingId = Guid.NewGuid().ToString();
            await _snowflake_service.InsertClaimAsync(claim, processingId);
            _logger.LogInformation($"Inserted claim {claim.ClaimId} into Snowflake (ProcessingId={processingId})");
        }
    }
}
