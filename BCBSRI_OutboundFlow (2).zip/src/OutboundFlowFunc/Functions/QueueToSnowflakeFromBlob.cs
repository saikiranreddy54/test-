using System;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using OutboundFlow.Shared.Interfaces;
using OutboundFlow.Shared.Models;
using System.Collections.Generic;
using System.Linq;

namespace OutboundFlowFunc.Functions
{
    public class QueueToSnowflakeFromBlob
    {
        private readonly IStorageService _storage;
        private readonly IMemberService _memberService;
        private readonly ISnowflakeService _snowService;
        private readonly ILogger<QueueToSnowflakeFromBlob> _logger;

        public QueueToSnowflakeFromBlob(IStorageService storage, IMemberService memberService, ISnowflakeService snowService, ILogger<QueueToSnowflakeFromBlob> logger)
        {
            _storage = storage;
            _memberService = memberService;
            _snowService = snowService;
            _logger = logger;
        }

        [Function("QueueToSnowflakeFromBlob") ]
        public async Task RunAsync([QueueTrigger("blob-notifications-queue", Connection = "AzureWebJobsStorage")] string queueMessage)
        {
            _logger.LogInformation("QueueToSnowflakeFromBlob triggered.");
            if (string.IsNullOrWhiteSpace(queueMessage)) return;

            string processingId = Guid.NewGuid().ToString();

            try
            {
                // Azure Event Grid message sometimes wrapped in an array - handle both shapes
                JsonElement rootElem;
                using (var doc = JsonDocument.Parse(queueMessage))
                {
                    var root = doc.RootElement;
                    // If message is an array, take first element
                    if (root.ValueKind == JsonValueKind.Array && root.GetArrayLength() > 0) rootElem = root[0];
                    else rootElem = root;
                }

                string blobUrl = null;
                if (rootElem.TryGetProperty("data", out var dataEl) && dataEl.ValueKind == JsonValueKind.Object)
                {
                    if (dataEl.TryGetProperty("url", out var urlEl)) blobUrl = urlEl.GetString();
                    else if (dataEl.TryGetProperty("uri", out var uriEl)) blobUrl = uriEl.GetString();
                }
                // fallback to subject path parsing
                if (string.IsNullOrEmpty(blobUrl) && rootElem.TryGetProperty("subject", out var subj)) {
                    // subject format: /blobServices/default/containers/{container}/blobs/{blobPath}
                    var subject = subj.GetString();
                    if (!string.IsNullOrEmpty(subject) && subject.Contains("/containers/"))
                    {
                        var parts = subject.Split(new[] {"/containers/"}, StringSplitOptions.None);
                        if (parts.Length > 1)
                        {
                            var rest = parts[1];
                            var idx = rest.IndexOf("/blobs/");
                            if (idx > -1)
                            {
                                var container = rest.Substring(0, idx);
                                var blobPath = rest.Substring(idx + "/blobs/".Length);
                                // build blob url using account from topic (best-effort) or use placeholder host from settings
                                var topic = rootElem.GetProperty("topic").GetString();
                                var accountHost = topic?.Split('/').LastOrDefault() ?? "<storage-account>.blob.core.windows.net";
                                blobUrl = $"https://{accountHost}/{container}/{blobPath}";
                            }
                        }
                    }
                }

                if (string.IsNullOrEmpty(blobUrl))
                {
                    _logger.LogWarning("Could not determine blob URL from queue message. Skipping.");
                    return;
                }

                _logger.LogInformation($"Resolved blob URL: {blobUrl}") ;

                // parse blobUrl to container + blobName
                var uri = new Uri(blobUrl);
                var segments = uri.AbsolutePath.TrimStart('/').Split('/', 2);
                if (segments.Length < 2) { _logger.LogWarning("Unexpected blob URL format"); return; }
                var containerName = segments[0];
                var blobName = segments[1];

                var content = await _storage.DownloadStringAsync(containerName, blobName);
                if (string.IsNullOrWhiteSpace(content))
                {
                    _logger.LogWarning("Blob content empty"); return;
                }

                List<ClaimEntity> claims = null;
                try { claims = JsonSerializer.Deserialize<List<ClaimEntity>>(content); } catch { claims = null; }

                if (claims == null || claims.Count == 0)
                {
                    try {
                        var single = JsonSerializer.Deserialize<ClaimEntity>(content);
                        if (single != null) claims = new List<ClaimEntity> { single };
                    } catch { claims = new List<ClaimEntity>(); }
                }

                if (claims == null || claims.Count == 0)
                {
                    _logger.LogInformation("No claims found in blob."); return;
                }

                foreach (var claim in claims)
                {
                    claim.RawPayload = content;
                    var claimProcessingId = Guid.NewGuid().ToString();

                    // Filter prime-pended claims (flag or status)
                    var isPrime = claim.PrimePended || string.Equals(claim.Status, "PENDED", StringComparison.OrdinalIgnoreCase) || string.Equals(claim.Status, "PRIME_PENDED", StringComparison.OrdinalIgnoreCase);
                    if (!isPrime)
                    {
                        _logger.LogInformation($"Skipping non-prime claim {claim.ClaimId}"); continue;
                    }

                    try
                    {
                        var memberJson = await _memberService.GetMemberAsync(claim.MemberId ?? string.Empty);
                        // Transform if required; currently we directly insert claim
                        await _snowService.InsertClaimAsync(claim, claimProcessingId);
                        _logger.LogInformation($"Inserted claim {claim.ClaimId} (proc={claimProcessingId})");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Failed to process claim {claim.ClaimId}") ;
                        var errMsg = ex.Message + (ex.InnerException != null ? ": " + ex.InnerException.Message : string.Empty);
                        try
                        {
                            await _snowService.InsertErrorAsync(claim.ClaimId ?? string.Empty, claimProcessingId, errMsg, claim.RawPayload ?? content);
                        }
                        catch (Exception innerEx)
                        {
                            _logger.LogError(innerEx, $"Failed to write error record for claim {claim.ClaimId}") ;
                            var errBlobName = $"error-{claim.ClaimId}-{DateTime.UtcNow:yyyyMMddHHmmssfff}.json";
                            await _storage.UploadErrorBlobAsync(containerName, errBlobName, JsonSerializer.Serialize(new { claim = claim, error = errMsg }));
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unhandled error in QueueToSnowflakeFromBlob"); throw;
            }
        }
    }
}
