using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using OutboundFlow.Shared.Interfaces;
using OutboundFlowFunc.Services;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        var conn = context.Configuration[""AzureWebJobsStorage""] ?? context.Configuration[""Azure:BlobConnection""] ?? ""UseDevelopmentStorage=true"";
        services.AddSingleton(new BlobServiceClient(conn));
        services.AddSingleton(new QueueServiceClient(conn));
        services.AddSingleton<IStorageService, AzureStorageService>();
        services.AddSingleton<IQueueService, AzureQueueService>();
        services.AddSingleton<IMemberService, MockMemberService>();
        services.AddSingleton<ISnowflakeService, SnowflakeService>();
    })
    .Build();

host.Run();
