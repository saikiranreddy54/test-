using System.IO;
using System.Threading.Tasks;

namespace OutboundFlow.Shared.Interfaces
{
    public interface IStorageService
    {
        Task UploadAsync(string containerName, string blobName, Stream content);
        Task<string> DownloadStringAsync(string containerName, string blobName);
        Task UploadErrorBlobAsync(string containerName, string blobName, string content);
    }
}
