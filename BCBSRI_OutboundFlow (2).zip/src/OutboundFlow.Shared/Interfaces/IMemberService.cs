using System.Threading.Tasks;

namespace OutboundFlow.Shared.Interfaces
{
    public interface IMemberService
    {
        Task<string> GetMemberAsync(string memberId);
    }
}
