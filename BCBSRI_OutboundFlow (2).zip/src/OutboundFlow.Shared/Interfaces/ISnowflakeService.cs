using System.Threading.Tasks;
using OutboundFlow.Shared.Models;

namespace OutboundFlow.Shared.Interfaces
{
    public interface ISnowflakeService
    {
        Task InsertClaimAsync(ClaimEntity claim, string processingId);
        Task InsertErrorAsync(string claimId, string processingId, string errorMessage, string rawPayload);
    }
}
