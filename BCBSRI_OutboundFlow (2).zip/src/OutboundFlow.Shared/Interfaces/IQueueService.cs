using System.Threading.Tasks;

namespace OutboundFlow.Shared.Interfaces
{
    public interface IQueueService
    {
        Task EnqueueAsync(string queueName, string message);
    }
}
