using System;
using System.Text.Json.Serialization;

namespace OutboundFlow.Shared.Models
{
    public class ClaimEntity
    {
        [JsonPropertyName("claimId")]
        public string ClaimId { get; set; }
        [JsonPropertyName("memberId")]
        public string MemberId { get; set; }
        [JsonPropertyName("status")]
        public string Status { get; set; }
        [JsonPropertyName("claimAmount")]
        public decimal ClaimAmount { get; set; }
        [JsonPropertyName("serviceDate")]
        public DateTime ServiceDate { get; set; }
        [JsonPropertyName("provider")]
        public string Provider { get; set; }
        [JsonPropertyName("diagnosisCode")]
        public string DiagnosisCode { get; set; }
        [JsonPropertyName("submittedAt")]
        public DateTime SubmittedAt { get; set; }
        [JsonPropertyName("primePended")]
        public bool PrimePended { get; set; }
        public string RawPayload { get; set; }
    }
}
