var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/api/member/{id}", (string id) =>
{
    return Results.Json(new { memberId = id, name = "John Doe", dob = "1970-01-01" });
});

app.Run();
