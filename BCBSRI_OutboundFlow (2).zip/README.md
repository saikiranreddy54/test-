BCBSRI Outbound Flow - Complete Scaffold
Generated: 2025-10-02T11:57:22.885522Z

This repository contains two outbound flows:
- Flow 1: Kafka -> Filter (IN_PROGRESS) -> Blob -> Queue -> Enrich -> Snowflake
- Flow 2: Event Grid/Blob Notification -> Queue -> Download Blob -> Filter (PRIME-PENDED) -> Enrich -> Snowflake with error logging

How to use (local):
1. Replace placeholder values in local.settings.json (Snowflake, Azure storage).
2. Start docker-compose to run Kafka, Zookeeper, Azurite and Mock Member API:
   docker compose up -d
3. Build & run Functions locally (requires Azure Functions Core Tools and .NET 6+):
   cd src/OutboundFlowFunc
   func start
4. Publish sample Kafka messages or upload sample blobs, then push sample queue message:
   PowerShell: .\scripts\publish-sample-claims.ps1
   PowerShell: .\scripts\enqueue-sample-queue-message.ps1

Notes:
- The SnowflakeService uses Snowflake.Data NuGet; provide a valid connection string under Snowflake__ConnectionString in local.settings.json.
- Terraform placeholders are under infra/terraform.
- Draw.io diagrams are under diagrams/*.drawio
