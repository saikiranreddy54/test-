# Enqueue sample Event Grid style message into Azure Storage Queue (Azurite)
# Requires Azure CLI or Azure Storage Explorer; this script shows an example using Azure CLI (az storage message put)
param(
    [string]$QueueName = "blob-notifications-queue",
    [string]$Connection = "UseDevelopmentStorage=true"
)
$sample = Get-Content -Raw -Path "scripts\sample_queue_message.json"
Write-Host "Use Azure Storage tools to enqueue this message into $QueueName. Example (Azure CLI):"
Write-Host "az storage message put --content '$sample' --queue-name $QueueName --connection-string '$Connection'"
