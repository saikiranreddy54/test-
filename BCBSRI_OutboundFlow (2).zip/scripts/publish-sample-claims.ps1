# Publish sample claims to Kafka (requires kafka container)
$broker = "localhost:9092"
$topic = "claims-topic"
$samples = "samples\kafka\claims.json"
Write-Host "Please publish the messages to Kafka using your local tool or docker exec kafka kafka-console-producer.sh ..."
